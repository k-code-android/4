package com.example.myfirstview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.widget.DatePicker;
import android.app.DatePickerDialog;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    String pwdValue,confirmPwdValue,submitMethod;
    DatePickerDialog dobPicker;
    private EditText dob;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Button View
        Button submitButton = findViewById(R.id.submit);
        //Password Text
        final EditText password = findViewById(R.id.password);
        //Confirm Password Text
        final EditText confirmPassword = findViewById(R.id.confirmPassword);
        dob = findViewById(R.id.dob);
        dob.setInputType(InputType.TYPE_NULL);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);

                // date picker dialog
                dobPicker = new
                        DatePickerDialog(MainActivity.this,AlertDialog.THEME_HOLO_LIGHT,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int
                                    monthOfYear, int dayOfMonth) {
                                //("dayOfMonth" + "/" + (monthOfYear + 1) + "/" + year);

                                dob.setText((dayOfMonth + "/" + (monthOfYear + 1) + "/" +
                                        year));

                            }
                        }, year, month, day);

                dobPicker.show();

            }

        });
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] submitLocation =
                        getResources().getStringArray(R.array.submit_type);
                pwdValue =password.getText().toString();
                confirmPwdValue = confirmPassword.getText().toString();
                if(!pwdValue.equals(confirmPwdValue) || pwdValue.isEmpty())
                {
                    AlertDialog.Builder alertDialogBuilder = new
                            AlertDialog.Builder(MainActivity.this);
                    // set title
                    alertDialogBuilder.setTitle("Error");
                    // set dialog message
                    alertDialogBuilder
                            .setMessage("Password and confirm password must be the same.")
                                            .setCancelable(false)
                                            .setPositiveButton("Ok",new
                                                    DialogInterface.OnClickListener() {
                                                        public void onClick(DialogInterface dialog,int
                                                                id) {
                                                            // if this button is clicked, close
                                                            // current activity
                                                            // Main2Activity.this.finish();
                                                            dialog.cancel();
                                                        }
                                                    });
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();
                    Button positiveButton =
                            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                    positiveButton.setTextColor(Color.parseColor("#FF0B8B42"));

                }
                else {


                    AlertDialog.Builder alertDialogBuilder = new
                            AlertDialog.Builder(
                            MainActivity.this)
                            .setTitle(R.string.alert_dialog_title)
                            .setItems(submitLocation, new OnClickListener() {

                                @Override
                                public void onClick(DialogInterface
                                                            dialog,int which) {
                                    submitMethod=submitLocation[which];
                                    // initiate a Toast with message and duration
                                    Toast toastMessage = Toast.makeText(getApplicationContext(),submitMethod, Toast.LENGTH_LONG);
                                    toastMessage.setGravity(Gravity.TOP |
                                            Gravity.START, 100, 0);
                                    toastMessage.show(); // display the Toast

                                }
                            })

                            .setNegativeButton(R.string.btn_Cancel, new
                                    OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog, int
                                                which) {
                                            dialog.dismiss();
                                        }
                                    });
                    AlertDialog dialog = alertDialogBuilder.create();
                    dialog.show();

                }
            }
        });

    }
}

